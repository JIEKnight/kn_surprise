function showDate(){
    var timeObj = new TimeObj();
    var year =  timeObj.year;
    var month = timeObj.month;
    var day = timeObj.day;
    month = doubleNum(month + 1);
    var str = year + '-' + (month) + '-' + day; 
    return str;
}// 显示时间

function showDay(){
    var timeObj = new TimeObj();
    week = dayOfWeek(timeObj.week);
    day = doubleNum(timeObj.day);
    hour = doubleNum(timeObj.hour);
    minute = doubleNum(timeObj.minute);
    second = doubleNum(timeObj.second);
    month = doubleNum(timeObj.month + 1);
    var str = `${timeObj.year}年${month}月${day}日 星期${week} ${hour}:${minute}:${second}`; 
    return str;
}

function TimeObj(){
    var d = new Date();
    this.year =  d.getFullYear();
    this.month = d.getMonth();
    this.day = d.getDate();
    this.week = d.getDay();
    this.hour = d.getHours();
    this.minute = d.getMinutes();
    this.second = d.getSeconds();
}

function dayOfWeek(week){
    var arr = ['日', '一', '二', '三', '四', '五', '六'];
    return arr[week];
}   

function doubleNum(num){
    if(num < 10){
        return '0' + num;
    }else{
        return num;
    }
}

function getDate(strDate){
    if(strDate==null||strDate===undefined) return null;
    var date = new Date();
    try{
      if(strDate == undefined){ 
        date= null;
      }else if(typeof strDate == 'string'){
        strDate = strDate.replace(/:/g,'-');
        strDate = strDate.replace(/ /g,'-');
        var dtArr = strDate.split("-");
        if(dtArr.length>=3&&dtArr.length<6){
          date=new Date(dtArr[0], dtArr[1], dtArr[2]);
        }else if(date.length>8){
          date=new Date(Date.UTC(dtArr[0],dtArr[1]-1,dtArr[2],dtArr[3]-8,dtArr[4],dtArr[5]));
        }
      }else{
        date = null;
      }
      return date;
    }catch(e){ 
      alert('格式化日期出现异常：' + e.message); 
    } 
}

function test(){
    var timeObj = new TimeObj();
    var time1 = showDate(); 
    var time2 = "2020-05-20";
    var timeslong = getDate(time1).getTime()-getDate(time2).getTime();
    // return (timeslong/(1000*60*60*24));
    return `${timeslong/(1000*60*60*24)}天${doubleNum(timeObj.hour)}时${doubleNum(timeObj.minute)}分${doubleNum(timeObj.second)}秒啦`; 
}

function slideShow(node, childNode, time){
  setInterval(function(){
      // console.log(childNode.);
      var offsetX = node.offsetLeft;
      startMove(node, {
          'left': node.offsetLeft - childNode.offsetWidth - 40
      },
      function(){
          if(node.offsetLeft <= -node.offsetWidth / 2){
          node.style.left = '0px';
      }
      }
      );           
  } ,time)
} // 轮播效果

function cpPlay(cp, audio, count){
  setInterval(function(){
  cp.style.transform = `rotateZ(${count % 360}deg)`;
  if(audio.paused){
      count = count;
  }else{
      count += 1;
  }
}, 30)
}// 唱片的旋转

function btnSwitch(audio, isPlay){
  if(audio.paused){
      audio.play()
      isPlay.className = 'iconfont icon-zanting';
  }else{
      audio.pause();
      isPlay.className = 'iconfont icon-kaishi';
  }
}// 开关的转换

function isPlay(audio, isPlay){
  if(audio.paused){
      // audio.play()
      isPlay.className = 'iconfont icon-kaishi';
  }else{
      // audio.pause();
     
      isPlay.className = 'iconfont icon-zanting';
  }
}// 检测是否播放

function progressBar(audio, past, current){
  setInterval(function(){
      var widthline = Math.round(audio.currentTime)/Math.round(audio.duration) * 100;
      past.style.width = widthline + "%";
      current.innerHTML = `${doubleNum(parseInt(Math.round(audio.currentTime)/60))}:${doubleNum(Math.round(audio.currentTime) % 60)}/${doubleNum(parseInt(Math.round(audio.duration)/60))}:${doubleNum(Math.round(audio.duration) % 60)}`;
      // console.log(Math.round(audio.duration));            
      },1000)
}// 进度条

function getSong(index, audio, songname){
  $ajax({
      method: 'get',
      url: 'getSong.php',
      success: function(result){
          var arr = JSON.parse(result);
          if(index < 0){
            index = arr.length - 1;
          };
          if(index == arr.length){
            index = 0;
          }
          audio.src = arr[index].url;
          songname.innerHTML = arr[index].songname;
          audio.index = index;
          // alert(arr);
      },
      error: function(msg){
          alert(msg);
      }
  });
}
